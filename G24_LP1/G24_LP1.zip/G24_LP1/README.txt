LargeNumber.java will go with LargeNumberOperations.java which contains subtraction

LargeNumbers.java contains Addition and Divide